@org.junit.jupiter.api.Test
void itShould${NAME}() {
  // Given
  // When
  // Then
}